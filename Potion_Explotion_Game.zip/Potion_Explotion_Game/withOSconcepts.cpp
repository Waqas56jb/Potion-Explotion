#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <mutex>
#include <thread>
#include <condition_variable>

using namespace std;

enum class Ingredient { APPLE, LEMON, CHERRY, WATER, SUGAR, STAR_ANISE, TOADSTOOL };

const int EXPLOSION_THRESHOLD = 3;
const int BOARD_SIZE = 5;

struct Board {
    vector<vector<Ingredient>> grid;
    vector<int> playerPositions;
    mutex boardMutex;
};

struct Player {
    int score = 0;
    vector<Ingredient> ingredients;
    int position = 0;
    mutex playerMutex;
};

bool processIngredient(Board& board, Player& player, Ingredient ingredient);
bool checkExplode(Board& board, vector<Player>& players);
void handleExplosion(Board& board, pair<int, int> cell, vector<Player>& players);
void displayBoard(const Board& board, const vector<Player>& players);
void playerTurn(Board& board, Player& player, vector<Player>& players);
void initializeGame(Board& board, vector<Player>& players);
bool isWinner(const Player& player);

void initializeGame(Board& board, vector<Player>& players) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0, static_cast<int>(Ingredient::TOADSTOOL));
                                 
    board.grid.resize(BOARD_SIZE, vector<Ingredient>(BOARD_SIZE, Ingredient::WATER));
    board.playerPositions = { 0, BOARD_SIZE - 1 };

    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            board.grid[i][j] = static_cast<Ingredient>(dis(gen));
        }
    }

    for (auto& player : players) {
        player.ingredients = { Ingredient::APPLE, Ingredient::LEMON, Ingredient::CHERRY };
        player.score = 0;
    }
}

void displayBoard(const Board& board, const vector<Player>& players) {
 

    cout << "\n********** BOARD **********\n";
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            cout << static_cast<int>(board.grid[i][j]) << " ";
        }
        cout << endl;
    }

    cout << "Player 1's Position: " << board.playerPositions[0] << endl;
    cout << "Player 2's Position: " << board.playerPositions[1] << endl;
    cout << "Player 1's Score: " << players[0].score << endl;
    cout << "Player 2's Score: " << players[1].score << endl;
}

void playerTurn(Board& board, Player& player, vector<Player>& players) {
    unique_lock<mutex> playerLock(player.playerMutex);

    cout << "Player " << player.position + 1 << ", it's your turn!" << endl;

    int move;
    do {
        cout << "Enter a move (1-left, 2-right): ";
        cin >> move;
    } while (move != 1 && move != 2);

    int newPosition = board.playerPositions[player.position] + (move == 1 ? -1 : 1);

    if (newPosition >= 0 && newPosition < BOARD_SIZE) {
        board.playerPositions[player.position] = newPosition;

        int ingredientChoice;
        do {
            cout << "Choose an ingredient to use:" << endl;
            for (int i = 0; i < player.ingredients.size(); ++i) {
                cout << static_cast<int>(player.ingredients[i]) << ": " << static_cast<int>(player.ingredients[i]) << " ";
            }
            cout << endl;

            cout << "Enter ingredient choice: ";
            cin >> ingredientChoice;
        } while (ingredientChoice < 1 || ingredientChoice > player.ingredients.size());

        processIngredient(board, player, player.ingredients[ingredientChoice - 1]);

        if (checkExplode(board, players)) {
            handleExplosion(board, { 0, 0 }, players);
        }
        player.score++;
    }
    else {
        cout << "Invalid move! You cannot move out of the board boundary." << endl;
    }
}

bool processIngredient(Board& board, Player& player, Ingredient ingredient) {
    lock_guard<mutex> lock(board.boardMutex);

    if (find(player.ingredients.begin(), player.ingredients.end(), ingredient) == player.ingredients.end()) {
        cout << "Invalid ingredient!" << endl;
        return false;
    }

    int currentPlayerPos = board.playerPositions[player.position];

    if (board.grid[currentPlayerPos][currentPlayerPos] != ingredient) {
        cout << "Ingredient doesn't match the cell!" << endl;
        return false;
    }

    player.ingredients.erase(remove(player.ingredients.begin(), player.ingredients.end(), ingredient), player.ingredients.end());

    board.grid[currentPlayerPos][currentPlayerPos] = Ingredient::STAR_ANISE;
    return true;
}

bool checkExplode(Board& board, vector<Player>& players) {
    lock_guard<mutex> lock(board.boardMutex);

    bool explosionDetected = false;

    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (board.grid[i][j] == Ingredient::STAR_ANISE) {
                board.grid[i][j] = Ingredient::WATER;
                for (int di = -1; di <= 1; ++di) {
                    for (int dj = -1; dj <= 1; ++dj) {
                        if (di != 0 || dj != 0) {
                            int ni = i + di, nj = j + dj;
                            if (ni >= 0 && ni < BOARD_SIZE && nj >= 0 && nj < BOARD_SIZE) {
                                if (board.grid[ni][nj] == board.grid[i][j]) {
                                    explosionDetected = true;
                                    handleExplosion(board, { ni, nj }, players);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return explosionDetected;
}

void handleExplosion(Board& board, pair<int, int> cell, vector<Player>& players) {
    int explosionRow = cell.first;
    int explosionCol = cell.second;

    unique_lock<mutex> lock(board.boardMutex);

    board.grid[explosionRow][explosionCol] = Ingredient::WATER;

    for (int di = -1; di <= 1; ++di) {
        for (int dj = -1; dj <= 1; ++dj) {
            int ni = explosionRow + di;
            int nj = explosionCol + dj;

            if (ni >= 0 && ni < BOARD_SIZE && nj >= 0 && nj < BOARD_SIZE) {
                if (board.grid[ni][nj] == board.grid[explosionRow][explosionCol]) {
                    if (ni != explosionRow || nj != explosionCol) {
                        if (board.grid[ni][nj] == Ingredient::STAR_ANISE) {
                            handleExplosion(board, { ni, nj }, players);
                        }
                    }
                }
            }
        }
    }

    int nextPlayerIndex = (players[0].position == players[1].position) ? 1 : 0;

    lock.unlock();

    playerTurn(board, players[nextPlayerIndex], players);
}

bool isWinner(const Player& player) {
    const int WINNING_SCORE = 10;
    return player.score >= WINNING_SCORE;
}

int main() {
    Board board;
    vector<Player> players(2);

    initializeGame(board, players);

    while (!isWinner(players[0]) && !isWinner(players[1])) {
        for (auto& player : players) {
            displayBoard(board, players);
            playerTurn(board, player, players);
            if (isWinner(player)) {
                cout << "Player " << player.position + 1 << " wins!" << endl;
                return 0;
            }
        }
    }

    return 0;
}

